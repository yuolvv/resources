#
# The content of this file will be filled in with meaningful data
# when creating an archive using `git archive` or by downloading an
# archive from github, e.g. from github.com/.../archive/develop.zip
#
rev = "964547c"     # abbreviated commit hash
commit = "964547cd92cabe28150d52c2ca809de74a5ddbaa"  # commit hash
date = "2017-04-18 11:45:00 +0200"   # commit date
author = "Hartmut Goebel <htgoebel@users.noreply.github.com>"
ref_names = "HEAD -> develop, refs/__gh__/pull/2480/rebase, refs/__gh__/pull/2375/rebase, refs/__gh__/pull/2346/rebase, refs/__gh__/pull/2323/rebase, refs/__gh__/pull/2269/rebase, refs/__gh__/pull/2214/rebase"  # incl. current branch
commit_message = """Merge pull request #2565 from springermac/fix-pylint-test

Hooks: Add setuptools.msvc hidden import"""
