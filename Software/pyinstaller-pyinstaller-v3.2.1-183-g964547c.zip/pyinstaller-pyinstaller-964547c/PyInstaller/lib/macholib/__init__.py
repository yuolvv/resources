"""
Enough Mach-O to make your head spin.

See the relevant header files in /usr/include/mach-o

And also Apple's documentation.
"""

# For PyInstaller/lib/ define the version here, since there is no
# package-resource.
__version__ = '1.7.0'
